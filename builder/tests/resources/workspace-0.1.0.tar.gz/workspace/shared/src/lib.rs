pub fn hello() -> &'static str {
    "Hello, shared"
}
